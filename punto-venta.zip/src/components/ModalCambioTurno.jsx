import { useState, useEffect } from "react";
import { getUsuarios, registrarCambioTurno, getCorteData } from "../api/api";
import { generarCambioTurnoPDF } from "../utils/generarPDF";
import styles from "./ModalCorte.module.css";

const DENOMS = [1000,500,200,100,50,20,10,5,2,1];

export default function ModalCambioTurno({ onCerrar, onRegistrado }) {
  const [usuarios,    setUsuarios]    = useState([]);
  const [corteData,   setCorteData]   = useState(null);
  const [cajeroSal,   setCajeroSal]   = useState("");
  const [cajeroEnt,   setCajeroEnt]   = useState("");
  const [denoms,      setDenoms]      = useState(Object.fromEntries(DENOMS.map(d=>[d,""])));
  const [guardando,   setGuardando]   = useState(false);
  const [fase,        setFase]        = useState("datos"); // datos | listo
  const [folio,       setFolio]       = useState("");

  useEffect(() => {
    getUsuarios().then(setUsuarios).catch(()=>{});
    getCorteData(1).then(setCorteData).catch(()=>{});
  }, []);

  const totalContado  = DENOMS.reduce((a,d) => a + d*(parseInt(denoms[d])||0), 0);
  const montoEsperado = parseFloat(corteData?.monto_en_caja||0);
  const excedente     = totalContado - montoEsperado;

  const registrar = async () => {
    if (guardando) return;
    setGuardando(true);
    try {
      const res = await registrarCambioTurno({
        id_caja:1,
        id_usuario_saliente: cajeroSal,
        id_usuario_entrante: cajeroEnt,
        denominaciones: denoms,
        total_contado: totalContado,
        excedente,
      });
      const folioRes = res.folio || `TUR-${Date.now()}`;
      setFolio(folioRes);
      generarCambioTurnoPDF({
        folio: folioRes,
        cajeroSaliente: usuarios.find(u=>String(u.id_usuario)===cajeroSal)?.nombre || "—",
        cajeroEntrante: usuarios.find(u=>String(u.id_usuario)===cajeroEnt)?.nombre || "—",
        caja: "Caja 1",
        montoEsperado, totalContado, excedente, denominaciones: denoms,
      });
      setFase("listo");
      if (onRegistrado) onRegistrado();
    } catch {
      const folioLocal = `TUR-${Date.now()}`;
      generarCambioTurnoPDF({
        folio: folioLocal,
        cajeroSaliente: usuarios.find(u=>String(u.id_usuario)===cajeroSal)?.nombre || "—",
        cajeroEntrante: usuarios.find(u=>String(u.id_usuario)===cajeroEnt)?.nombre || "—",
        caja: "Caja 1",
        montoEsperado, totalContado, excedente, denominaciones: denoms,
      });
      setFolio(folioLocal);
      setFase("listo");
      if (onRegistrado) onRegistrado();
    } finally { setGuardando(false); }
  };

  return (
    <div className={styles.overlay} onClick={onCerrar}>
      <div className={styles.modal} onClick={e=>e.stopPropagation()}>
        <div className={styles.header}>
          <span className={styles.titulo}>🔄 Cambio de turno</span>
          <button className={styles.cerrarBtn} onClick={onCerrar}>✕</button>
        </div>

        {fase === "datos" && (
          <>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <div>
                <div className={styles.seccionTitulo}>Cajero saliente</div>
                <select style={{width:"100%",background:"var(--surface2)",border:"1px solid var(--border)",borderRadius:10,padding:"8px 12px",fontSize:13,outline:"none"}}
                  value={cajeroSal} onChange={e=>setCajeroSal(e.target.value)}>
                  <option value="">Seleccionar...</option>
                  {usuarios.map(u=><option key={u.id_usuario} value={u.id_usuario}>{u.nombre}</option>)}
                </select>
              </div>
              <div>
                <div className={styles.seccionTitulo}>Cajero entrante</div>
                <select style={{width:"100%",background:"var(--surface2)",border:"1px solid var(--border)",borderRadius:10,padding:"8px 12px",fontSize:13,outline:"none"}}
                  value={cajeroEnt} onChange={e=>setCajeroEnt(e.target.value)}>
                  <option value="">Seleccionar...</option>
                  {usuarios.map(u=><option key={u.id_usuario} value={u.id_usuario}>{u.nombre}</option>)}
                </select>
              </div>
            </div>

            <div className={styles.seccionTitulo}>Conteo de efectivo</div>
            <div className={styles.denomGrid}>
              {DENOMS.map(d=>(
                <div key={d} className={styles.denomRow}>
                  <span className={styles.denomLabel}>${d}</span>
                  <span className={styles.denomX}>×</span>
                  <input className={styles.denomInput} type="number" min={0} placeholder="0"
                    value={denoms[d]} onChange={e=>setDenoms(p=>({...p,[d]:e.target.value}))} />
                  <span className={styles.denomSub}>= ${(d*(parseInt(denoms[d])||0)).toFixed(0)}</span>
                </div>
              ))}
            </div>

            <div className={styles.conteoResumen}>
              <div className={styles.conteoRow}><span>Total contado</span><span className={styles.conteoVal}>${totalContado.toFixed(2)}</span></div>
              <div className={styles.conteoRow}><span>Esperado en caja</span><span>${montoEsperado.toFixed(2)}</span></div>
              <div className={`${styles.conteoRow} ${excedente>0?styles.sobrante:excedente<0?styles.faltante:styles.exacto}`}>
                <span>{excedente>0?"Excedente":excedente<0?"Faltante":"✓ Cuadrado"}</span>
                <span>{excedente!==0?`${excedente>0?"+":""}$${excedente.toFixed(2)}`:""}</span>
              </div>
            </div>

            <div style={{fontSize:11,color:"var(--muted)",textAlign:"center"}}>
              Este documento no afecta el corte final de caja
            </div>

            <div className={styles.footerBtns}>
              <button className={styles.btnSecundario} onClick={onCerrar}>Cancelar</button>
              <button className={styles.btnPrimario} onClick={registrar} disabled={guardando || !cajeroSal || !cajeroEnt}>
                {guardando ? "Registrando..." : "Registrar y generar PDF"}
              </button>
            </div>
          </>
        )}

        {fase === "listo" && (
          <div className={styles.listoWrap}>
            <div className={styles.listoCheck}>✓</div>
            <div className={styles.listoTitulo}>Cambio de turno registrado</div>
            <div className={styles.listoFolio}>{folio}</div>
            <div className={styles.footerBtns}>
              <button className={styles.btnPrimario} onClick={onCerrar}>Listo</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
