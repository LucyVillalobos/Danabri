import { useState, useEffect } from "react";
import logo from "../assets/DanabriLogoRecortado.png";
import { useCart } from "../context/CartContext";
import styles from "./Header.module.css";

function Header({ onVerHistorial }) {
  const [hora, setHora] = useState("");
  const { ventasHoy = 0, productosVendidos = 0 } = useCart() ?? {};

  useEffect(() => {
    const actualizar = () => {
      setHora(new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }));
    };
    actualizar();
    const intervalo = setInterval(actualizar, 1000);
    return () => clearInterval(intervalo);
  }, []);

  return (
    <header className={styles.header}>
      <div className={styles.logoWrap}>
        <img src={logo} alt="Papelera Danabri" className={styles.logo} />
      </div>

      <div className={styles.center}>
        <button className={styles.statBtn} onClick={onVerHistorial}>
          <span className={styles.statLabel}>Ventas hoy</span>
          <span className={styles.statVal}>${ventasHoy.toFixed(2)}</span>
        </button>
        <div className={styles.statDivider} />
        <button className={styles.statBtn} onClick={onVerHistorial}>
          <span className={styles.statLabel}>Productos vendidos</span>
          <span className={styles.statVal}>{productosVendidos}</span>
        </button>
      </div>

      <div className={styles.right}>
        <div className={styles.badge}>{hora}</div>
        <div className={styles.badge}>Lucy</div>
        <div className={styles.badge}>Sucursal Centro</div>
      </div>
    </header>
  );
}

export default Header;