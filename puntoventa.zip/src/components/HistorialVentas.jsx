import { useCart } from "../context/CartContext";
import styles from "./HistorialVentas.module.css";

const METODO_EMOJI = { efectivo: "💵", tarjeta: "💳", transferencia: "📱" };

function HistorialVentas({ onCerrar }) {
  const { historial, ventasHoy, productosVendidos } = useCart();

  return (
    <div className={styles.overlay} onClick={onCerrar}>
      <div className={styles.panel} onClick={(e) => e.stopPropagation()}>

        <div className={styles.header}>
          <span className={styles.titulo}>Ventas del día</span>
          <button className={styles.cerrarBtn} onClick={onCerrar}>✕</button>
        </div>

        {/* Stats */}
        <div className={styles.stats}>
          <div className={styles.statCard}>
            <span className={styles.statLabel}>Total recaudado</span>
            <span className={styles.statVal}>${ventasHoy.toFixed(2)}</span>
          </div>
          <div className={styles.statCard}>
            <span className={styles.statLabel}>Órdenes</span>
            <span className={styles.statVal}>{historial.length}</span>
          </div>
          <div className={styles.statCard}>
            <span className={styles.statLabel}>Productos</span>
            <span className={styles.statVal}>{productosVendidos}</span>
          </div>
        </div>

        {/* Lista */}
        <div className={styles.lista}>
          {historial.length === 0 ? (
            <div className={styles.empty}>
              <span className={styles.emptyIcon}>🧾</span>
              <span className={styles.emptyText}>Sin ventas aún hoy</span>
            </div>
          ) : (
            historial.map((venta, i) => (
              <div key={i} className={styles.venta}>
                <div className={styles.ventaTop}>
                  <div className={styles.ventaInfo}>
                    <span className={styles.ventaCliente}>{venta.cliente}</span>
                    <span className={styles.ventaHora}>{venta.hora}</span>
                  </div>
                  <div className={styles.ventaRight}>
                    <span className={styles.ventaMetodo}>
                      {METODO_EMOJI[venta.metodo]} {venta.metodo}
                    </span>
                    <span className={styles.ventaTotal}>${venta.total.toFixed(2)}</span>
                  </div>
                </div>
                <div className={styles.ventaItems}>
                  {venta.items.map((item, j) => (
                    <span key={j} className={styles.ventaItem}>
                      {item.emoji} {item.nombre} ×{item.cantidad}
                    </span>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default HistorialVentas;