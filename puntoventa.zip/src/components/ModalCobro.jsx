import { useState } from "react";
import { useCart } from "../context/CartContext";
import styles from "./ModalCobro.module.css";

const CLIENTES = [
  { id: 0, nombre: "Cliente General" },
  { id: 1, nombre: "María García" },
  { id: 2, nombre: "Juan Pérez" },
  { id: 3, nombre: "Sofía Ramírez" },
  { id: 4, nombre: "Carlos López" },
];

const METODOS = [
  { id: "efectivo",      label: "Efectivo",       emoji: "💵" },
  { id: "tarjeta",       label: "Tarjeta",         emoji: "💳" },
  { id: "transferencia", label: "Transferencia",   emoji: "📱" },
];

function ModalCobro({ total, subtotal, iva, items, onCerrar, onConfirmar }) {
  const { registrarVenta = () => {} } = useCart() ?? {};
  const [metodo,      setMetodo]    = useState("efectivo");
  const [clienteId,   setClienteId] = useState(0);
  const [efectivoStr, setEfectivo]  = useState("");
  const [fase,        setFase]      = useState("cobro");

  const efectivoPago = parseFloat(efectivoStr) || 0;
  const cambio       = efectivoPago - total;
  const pagoValido   = metodo !== "efectivo" || efectivoPago >= total;

  const confirmar = () => {
    if (!pagoValido) return;
    registrarVenta({
      cliente: CLIENTES[clienteId].nombre,
      metodo,
      total,
      subtotal,
      iva,
      items,
      hora: new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }),
    });
    setFase("ticket");
  };

  const cerrarTicket = () => { onConfirmar(); onCerrar(); };

  const hora = new Date().toLocaleString("es-MX", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });

  return (
    <div className={styles.overlay} onClick={onCerrar}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>

        {fase === "cobro" ? (
          <>
            <div className={styles.modalHeader}>
              <span className={styles.modalTitulo}>Cobrar orden</span>
              <button className={styles.cerrarBtn} onClick={onCerrar}>✕</button>
            </div>

            <div className={styles.seccion}>
              <label className={styles.label}>Cliente</label>
              <select className={styles.select} value={clienteId} onChange={(e) => setClienteId(Number(e.target.value))}>
                {CLIENTES.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
              </select>
            </div>

            <div className={styles.seccion}>
              <label className={styles.label}>Método de pago</label>
              <div className={styles.metodos}>
                {METODOS.map((m) => (
                  <button
                    key={m.id}
                    className={`${styles.metodoBtn} ${metodo === m.id ? styles.metodoBtnActivo : ""}`}
                    onClick={() => setMetodo(m.id)}
                  >
                    <span>{m.emoji}</span>
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {metodo === "efectivo" && (
              <div className={styles.seccion}>
                <label className={styles.label}>Pago con</label>
                <div className={styles.inputWrap}>
                  <span className={styles.inputPrefix}>$</span>
                  <input
                    className={styles.input}
                    type="number"
                    placeholder="0.00"
                    value={efectivoStr}
                    onChange={(e) => setEfectivo(e.target.value)}
                    min={0}
                    autoFocus
                  />
                </div>
                {efectivoPago > 0 && (
                  <div className={`${styles.cambio} ${cambio < 0 ? styles.cambioNeg : styles.cambioPos}`}>
                    {cambio < 0 ? `Faltan $${Math.abs(cambio).toFixed(2)}` : `Cambio: $${cambio.toFixed(2)}`}
                  </div>
                )}
              </div>
            )}

            <div className={styles.resumen}>
              <div className={styles.resumenRow}><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
              <div className={styles.resumenRow}><span>IVA 16%</span><span>${iva.toFixed(2)}</span></div>
              <div className={`${styles.resumenRow} ${styles.resumenTotal}`}>
                <span>Total</span><span>${total.toFixed(2)}</span>
              </div>
            </div>

            <button className={styles.confirmarBtn} onClick={confirmar} disabled={!pagoValido}>
              Confirmar cobro · ${total.toFixed(2)}
            </button>
          </>
        ) : (
          <>
            <div className={styles.ticketHeader}>
              <div className={styles.ticketCheck}>✓</div>
              <div className={styles.ticketTitulo}>¡Venta completada!</div>
              <div className={styles.ticketSub}>{hora}</div>
            </div>

            <div className={styles.ticket}>
              <div className={styles.ticketNegocio}>PAPELERA DANABRI</div>
              <div className={styles.ticketSucursal}>Sucursal Centro</div>
              <div className={styles.ticketDivider} />
              <div className={styles.ticketCliente}>Cliente: {CLIENTES[clienteId].nombre}</div>
              <div className={styles.ticketDivider} />
              {items.map((item, i) => (
                <div key={i} className={styles.ticketItem}>
                  <span className={styles.ticketItemNombre}>{item.emoji} {item.nombre}</span>
                  <span className={styles.ticketItemQty}>x{item.cantidad}</span>
                  <span className={styles.ticketItemPrecio}>${(item.precio * item.cantidad).toFixed(2)}</span>
                </div>
              ))}
              <div className={styles.ticketDivider} />
              <div className={styles.ticketRow}><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
              <div className={styles.ticketRow}><span>IVA</span><span>${iva.toFixed(2)}</span></div>
              <div className={`${styles.ticketRow} ${styles.ticketRowTotal}`}>
                <span>TOTAL</span><span>${total.toFixed(2)}</span>
              </div>
              <div className={styles.ticketDivider} />
              <div className={styles.ticketRow}><span>Método</span><span>{METODOS.find(m => m.id === metodo)?.label}</span></div>
              {metodo === "efectivo" && (
                <>
                  <div className={styles.ticketRow}><span>Pago</span><span>${efectivoPago.toFixed(2)}</span></div>
                  <div className={styles.ticketRow}><span>Cambio</span><span>${cambio.toFixed(2)}</span></div>
                </>
              )}
              <div className={styles.ticketDivider} />
              <div className={styles.ticketGracias}>¡Gracias por su compra!</div>
            </div>

            <div className={styles.ticketBtns}>
              <button className={styles.imprimirBtn} onClick={() => window.print()}>🖨️ Imprimir</button>
              <button className={styles.confirmarBtn} onClick={cerrarTicket}>Nueva venta</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default ModalCobro;