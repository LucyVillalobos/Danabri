import { useCart } from "../context/CartContext";
import styles from "./ListaProductos.module.css";

const STOCK_BAJO = 5;

function ListaProductos({ productos }) {
  const { carrito, agregar } = useCart();

  return (
    <div className={styles.grid}>
      {productos.map((producto) => {
        const cantidad  = carrito[producto.id]?.cantidad || 0;
        const agotado   = producto.stock === 0;
        const stockBajo = producto.stock > 0 && producto.stock <= STOCK_BAJO;

        return (
          <div
            key={producto.id}
            className={`${styles.card} ${agotado ? styles.out : ""} ${stockBajo ? styles.stockBajo : ""}`}
            onClick={() => !agotado && agregar(producto)}
          >
            {/* Badge cantidad en carrito */}
            {cantidad > 0 && (
              <div className={styles.badgeCart}>{cantidad}</div>
            )}

            {/* Badge stock bajo / agotado */}
            {agotado && <div className={`${styles.badgeStock} ${styles.agotado}`}>Agotado</div>}
            {stockBajo && <div className={`${styles.badgeStock} ${styles.bajo}`}>⚠ {producto.stock} left</div>}

            <span className={styles.emoji}>{producto.emoji}</span>
            <div className={styles.nombre}>{producto.nombre}</div>
            <div className={styles.precio}>${producto.precio}</div>
            <div className={styles.stock}>
              {agotado ? "Sin existencias" : `${producto.stock} disp.`}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default ListaProductos;