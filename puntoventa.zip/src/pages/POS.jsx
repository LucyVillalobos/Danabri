import { useState } from "react";
import Header from "../components/Header";
import Buscador from "../components/Buscador";
import ListaProductos from "../components/ListaProductos";
import Carrito from "../components/Carrito";
import HistorialVentas from "../components/HistorialVentas";
import productos from "../data/productos";
import styles from "./POS.module.css";

function POS() {
  const [busqueda,        setBusqueda]        = useState("");
  const [categoria,       setCategoria]       = useState("Todos");
  const [historialAbierto, setHistorialAbierto] = useState(false);

  const categorias = ["Todos", ...new Set(productos.map((p) => p.categoria))];

  const productosFiltrados = productos.filter((p) => {
    const matchCat     = categoria === "Todos" || p.categoria === categoria;
    const matchBusqueda = p.nombre.toLowerCase().includes(busqueda.toLowerCase());
    return matchCat && matchBusqueda;
  });

  return (
    <div className={styles.posContainer}>
      <div className={styles.posLeft}>
        <Header onVerHistorial={() => setHistorialAbierto(true)} />
        <Buscador
          busqueda={busqueda}
          setBusqueda={setBusqueda}
          categorias={categorias}
          categoria={categoria}
          setCategoria={setCategoria}
        />
        <ListaProductos productos={productosFiltrados} />
      </div>

      <Carrito />

      {historialAbierto && (
        <HistorialVentas onCerrar={() => setHistorialAbierto(false)} />
      )}
    </div>
  );
}

export default POS;